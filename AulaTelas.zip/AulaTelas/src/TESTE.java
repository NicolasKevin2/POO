import javax.swing.*;

public class TESTE {
    private JPanel panel1;
    private JMenu jm1;
    private JMenu jm2;
    private JMenuItem jm11;
    private JMenuItem jm12;
    private JMenuItem jm13;
}
