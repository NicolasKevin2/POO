import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaPrincipal {
    public JPanel panelPrincipal;
    private JMenuBar JMB;
    private JMenu JM;
    private JMenu JM4;
    private JMenuItem m1;
    private JMenuItem m2;
    private JMenuItem m3;
    private JMenuItem sair;
    private JMenu JM2;
    private JMenu JM3;
    private JMenuItem m4;


    public TelaPrincipal() {

        m1.addActionListener(new ActionListener() {
            /**
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame t = new JFrame("TelaClientes");
                t.setContentPane(new TelaClientes().jpcliente);
                t.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                t.pack();
                t.setResizable(false);
                t.setSize(500,500);
                t.setLocationRelativeTo(null);
                t.setVisible(true);
            }
        });
        sair.addActionListener(new ActionListener() {
            /**
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }


    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
