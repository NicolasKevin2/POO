package Classes;

public class Clientes extends Pai{

}
