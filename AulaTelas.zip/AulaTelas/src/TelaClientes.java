

import Classes.Clientes;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class TelaClientes {
    public JButton sairButton;
    public JPanel jpcliente;
    private JTextField txtId;
    private JTextField txtNome;
    private JTextField txtCpf;
    private JTextField txtEmail;
    private JButton btnGravar;

    public TelaClientes() {



        btnGravar.addActionListener(new ActionListener() {
            /**
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                //captura os dados inseridos pelo usuario
               int id = Integer.parseInt(txtId.getText());
               String nome = txtNome.getText();
               String cpf = txtCpf.getText();
               String email = txtEmail.getText();
               // instancio um objeto da classe clientes
                // e guardo os dados no atributo da classe clientes
                Clientes cli1 = new Clientes();
                cli1.setId(id);
                cli1.setNome(nome);
                cli1.setCpf(cpf);
                cli1.setEmail(email);
                // imprimo os dados dos atributos
                JOptionPane.showMessageDialog(null,
                "Id "+"\n"+cli1.getId()+"\n"+
                        "Nome "+"\n"+cli1.getNome()+"\n"+
                        "Cpf "+"\n"+cli1.getCpf()+"\n"+
                        "Email "+"\n"+cli1.getEmail());
            }
        });

        
    }
}
